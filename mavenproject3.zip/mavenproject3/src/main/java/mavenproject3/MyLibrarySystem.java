
package mavenproject3;
import java.util.ArrayList;
import java.util.List;

// THIS A CLASS HAS BEEN DONE BY 
//MyLibrarySystem Class - Manage Books and Operations
public class MyLibrarySystem {
    private ArrayList<BOOKS00> books = new ArrayList<>();

    public void addBook(String title, String author, String genre, String language, String publicationDate, String description, double price, boolean isAvailable) {
       BOOKS00 newBook = new BOOKS00(title, author, genre, language, publicationDate, description, price, isAvailable);
        books.add(newBook);
        System.out.println("Book added: " + title);
    }

    public void removeBook(String title) {
        books.removeIf(book -> book.getTitle().equalsIgnoreCase(title));
        System.out.println("Book removed: " + title);
    }

    public void displayBooks() {
        if (books.isEmpty()) {
            System.out.println("No books available.");
        } else {
            System.out.println("Books in the library:");
            for (BOOKS00 book : books) {
                book.displayBOOK0();
            }
        }
    }

    public List<BOOKS00> getBooks() {
        return books;
    }

    public static List<BOOKS00> filterBooks(List<BOOKS00> books, String criterion, String value) {
        List<BOOKS00> filteredBooks = new ArrayList<>();

        for (BOOKS00 book : books) {
            switch (criterion.toLowerCase()) {
                case "title":
                    if (book.getTitle().equalsIgnoreCase(value)) {
                        filteredBooks.add(book);
                    }
                    break;
                case "author":
                    if (book.getAuthor().equalsIgnoreCase(value)) {
                        filteredBooks.add(book);
                    }
                    break;
                case "genre":
                    if (book.getGenre().equalsIgnoreCase(value)) {
                        filteredBooks.add(book);
                    }
                    break;
                case "language":
                    if (book.getLanguage().equalsIgnoreCase(value)) {
                        filteredBooks.add(book);
                    }
                    break;
                case "availability":
                    if ((value.equalsIgnoreCase("available") && book.isAvailable()) ||
                        (value.equalsIgnoreCase("unavailable") && !book.isAvailable())) {
                        filteredBooks.add(book);
                    }
                    break;
                default:
                    System.out.println("Invalid criterion. You can filter by 'title', 'author', 'genre', 'language', or 'availability'.");
                    return filteredBooks;
            }
        }
        return filteredBooks;
    }}//END OF CLASS
