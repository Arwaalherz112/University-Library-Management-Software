
package mavenproject3;

// THIS IS A CLASS HAS BEEN DONE BY ZAHRA:
//Admin Class - Subclass of MyLibrarySystem
public class Admin extends MyLibrarySystem {
    private String[] adminNames = {"Rawan", "Jumana", "Arwa", "Kady", "Fatimah", "Zahra"};
    private String[] adminPasswords = {"password1", "re3567u", "h5k456", "fea99r5", "fat4568", "zhe4567"};
 
    public Admin() {
        super();  
    }
    public Admin(String[] adminName, String[] adminPassword) {
        this.adminNames = adminName;
        this.adminPasswords = adminPassword;
    }

    public String [] getAdminName() {
        return adminNames;
    }
    public String[] getAdminPassword() {
        return adminPasswords;
    }

    
    public void addBookByAdmin(String title, String author, String genre, String language, String publicationDate, String description, boolean isAvailable) {
        super.addBook(title, author, genre, language, publicationDate, description,0, isAvailable);
    }

    public void removeBookByAdmin(String title) {
        super.removeBook(title);
    }

    public void displayAllUsers(LoginPage[] users, int userCount) {
        if (userCount == 0) {
            System.out.println("No registered users.");
        } else {
            System.out.println("Registered Users:");
            for (int i = 0; i < userCount; i++) {
                System.out.println("ID: " + users[i].getUserID() + ", Name: " + users[i].getName() + ", Email: " + users[i].getEmail());
            }
        }
    }
    
    public boolean login(String [] username, String[] password) {
      return this.adminNames.equals(username) && this.adminPasswords.equals(password);
        }
}// END OF CLASS
