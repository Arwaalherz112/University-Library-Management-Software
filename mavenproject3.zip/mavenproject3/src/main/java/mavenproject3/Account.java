
package mavenproject3;

import java.time.LocalDate;
// THIS IS A CLASS HAS BEEN DONE BY JUMANA:
//Account Class - Subclass of LoginPage
public class Account extends LoginPage{
        private String borrowedBook ;
        private LocalDate purchaseDate ;
        private LocalDate dueDate ;
        
        
        public Account( String borrowedBook, LocalDate purchaseDate, LocalDate dueDate){
        super();
        this.borrowedBook = borrowedBook;
        this.purchaseDate = purchaseDate;
        this.dueDate = dueDate;   
        }
    public String getBorrowedBook() {
        return borrowedBook;
    }
    public void setBorrowedBook(String borrowedBook) { 
        this.borrowedBook = borrowedBook;
    }
    public LocalDate getPurchaseDate() {
        return purchaseDate; 
    }
    public void setPurchaseDate(LocalDate purchaseDate) {
        this.purchaseDate = purchaseDate; 
    }
    public LocalDate getDueDate() { 
        return dueDate;
    }
    public void setDueDate(LocalDate dueDate) { 
        this.dueDate = dueDate; 
    }
}
    //THE END OF CLASS
    