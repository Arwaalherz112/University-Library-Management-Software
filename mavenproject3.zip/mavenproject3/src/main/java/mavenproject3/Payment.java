
package mavenproject3;

import java.time.LocalDate;

// THIS IS A CLASS HAS BEEN DONE BY KADY:
 //Payment Class - Manages payment details for account

public class Payment extends Account{
    
    private float amount;
    private LocalDate dateOfReturn;

  
    public Payment(String borrowedBook, LocalDate purchaseDate,LocalDate dueDate,float amount, LocalDate dateOfReturn) {
        super(borrowedBook,purchaseDate,dueDate);
        this.amount = amount;
        this.dateOfReturn = dateOfReturn;
    }

  
    public float getAmount() { 
        return amount;
    }
    public void setAmount(float amount) {
        this.amount = amount;
    }

   

    public LocalDate getDateOfReturn() {
        return dateOfReturn; 
    }
    public void setDateOfReturn(LocalDate dateOfReturn) {
        this.dateOfReturn = dateOfReturn; 
    }

   

    public void increaseAmount(float A) {
        this.amount += A;
        System.out.println("Amount has been increased. New Amount: " + this.amount);
    }}
 