package mavenproject3;


//THIS IS A CLASS HAS BEEN DONE BY ARWA:
//BOOKS00 Class - Represents the Book
    public class BOOKS00 {
        
    private int bookID;
    private static int idCounter = 1;
    private String title;
    private String author;
    private String genre;
    private String language;
    private String publicationDate;
    private String description;
    private double price;
    private boolean isAvailable;
    

public BOOKS00(String title, String author, String genre, String language, String publicationDate, String description, double price, boolean isAvailable) {
 
    this.bookID = idCounter++;
    this.title = title;
    this.author = author;
    this.genre = genre;
    this.language = language;
    this.publicationDate = publicationDate;
    this.description = description;
    this.price = price;
    //this.setPrice(price);
    this.isAvailable = isAvailable;
}


  public int getBookID() {
        return bookID;
    }

public String getTitle() {
    return title;
}

public String getAuthor() {
    return author;
}

public String getGenre() {
    return genre;
}

public String getLanguage() {
    return language;
}

public String getPublicationDate() {
    return publicationDate;
}

public String getDescription() {
    return description;
}

public double getPrice() {
    return price;
}
/*
public void setPrice(double price) {
    if (price < 0) {
    throw new IllegalArgumentException("Price cannot be negative.");}
    this.price=price;}*/

public boolean isAvailable() {
    return isAvailable;
}
public void setAvailable(boolean isAvailable) {
    this.isAvailable = isAvailable;
}


public void displayBOOK0() {
    System.out.println("Title: " + title);
    System.out.println("Author: " + author);
    System.out.println("Genre: " + genre);
    System.out.println("Language: " + language);
    System.out.println("Publication Date: " + publicationDate);
    System.out.println("Description: " + description);
    System.out.println("Price: " + price);
    System.out.println("Available: " + isAvailable);
}
   //Borrow a book
    public boolean borrowBook() {
    if (isAvailable) {
    isAvailable = false;
       System.out.println("The book " + title + "has been borrowed.");
       return true;
    } else {
        System.out.println("The book " + title + " is not available.");
        return false;
        }
    }

    // Return a book
    public void returnBook() {
        isAvailable = true;
        System.out.println("The book \"" + title + "\" has been returned.");
    }

   // Buy a book
    public boolean buyBook() {
        if (isAvailable) {
            System.out.println("The book " + title + " has been purchased for $" + price + ".");
            return true;
        } else {
            System.out.println("The book " + title + " is not available for purchase.");
            return false;
        }
    }
 }//END OF CLASS