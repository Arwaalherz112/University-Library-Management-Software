

package mavenproject3;

import java.util.Scanner;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Mavenproject3 {
     public static void main(String[] args) {
     
        Scanner in = new Scanner(System.in);
        //MyLibrarySystem library = null;
        String[] adminNames = {"Rawan", "Jumana", "Arwa", "Kady", "Fatimah", "Zahra"};
     String[] adminPasswords = {"password1", "re3567u", "h5k456", "fea99r5", "fat4568", "zhe4567"};
        Scanner input = new Scanner(System.in);
        LoginPage[] users = new LoginPage[10]; 
       Admin admin = new Admin();
        int userCount = 0;

        System.out.println("Welcome to our library!");
        System.out.println("_______________________");

       
            System.out.println("Enter 1 to register");
            System.out.println("Enter 2 to login");
            System.out.println("Enter 3 to exit");
            int num = input.nextInt();

            if (num == 1) {
               
                System.out.print("Enter your ID number : ");
                int userID = input.nextInt();

                System.out.print("Enter username: ");
                String name = input.next();

                System.out.print("Enter your email: ");
                String email = input.next();

                System.out.print("Enter your password: ");
                String password = input.next();

                boolean newuser = false;
                for (int i = 0; i < userCount; i++) {
                    if (users[i].getName().equals(name)) {
                        newuser = true;
                    }
                }

                if (newuser) {
                    System.out.println("The username is already in use, Please enter a different username.");
                } 
                else {
                    users[userCount] = new LoginPage(userID, name, email, password){};
                    userCount++;
                    System.out.println("Registration successful!");
                }
            } 
            else if (num == 2) {
                System.out.print("Enter your username: ");
                String username = input.next();
                System.out.print("Enter your password: ");
                String password = input.next();

    if (admin.login(adminNames, adminPasswords)){
    System.out.println("Admin login successful!");

   
        System.out.println("Admin Menu:");
        System.out.println("1. Add a Book");
        System.out.println("2. Remove a Book");
        System.out.println("3. Display All Books");
        System.out.println("4. Display All Users");
        System.out.println("5. Exit");
        System.out.print("Choose an option: ");
        int adminChoice = input.nextInt();

        switch (adminChoice) {
            case 1:
                System.out.print("Enter book title: ");
                String title = input.nextLine();

                System.out.print("Enter author: ");
                String author = input.nextLine();

                System.out.print("Enter genre: ");
                String genre = input.nextLine();

                System.out.print("Enter language: ");
                String language = input.nextLine();

                System.out.print("Enter publication date: ");
                String publicationDate = input.nextLine();

                System.out.print("Enter description: ");
                String description = input.nextLine();

                System.out.print("Is the book available? (true/false): ");
                boolean isAvailable = input.nextBoolean();

                admin.addBookByAdmin(title, author, genre, language, publicationDate, description, isAvailable);
                break;

            case 2:
                System.out.print("Enter book title to remove: ");
                title = input.nextLine();
                admin.removeBookByAdmin(title);
                break;

            case 3:
                admin.displayBooks();
                break;

            case 4:
                admin.displayAllUsers(users, userCount);
                break;

            case 5:
                System.out.println("Admin logged out.");
                break;

            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
 else {
    System.out.println("Admin login failed. Incorrect username or password.");
}

               boolean login = false;
                for (int i = 0; i < userCount; i++) {
                    if (users[i].getEmail().equals(username) && users[i].getPassword().equals(password)) {
                        System.out.println("Login successful! Welcome, " + username + "!");
                        login = true;
                    } }}
                    else if (num == 3) {
                System.out.println("Goodbye!");
                    } 
            else {
                System.out.println("wrong... Please try again.");
                    }
        
    
            //--------------------------------
            // Account user = new Account(); 
            LocalDate purchaseDate = LocalDate.now();
            LocalDate dueDate = purchaseDate.plusDays(7);
           Account account = new Account("Clean Code, Java Performance", purchaseDate, dueDate);
           System.out.println("The Account Information");
           System.out.println(" Enter 1 to see borrowed Book");
            System.out.println(" Enter 2 to see Purchase Date ");
            System.out.println("Enter 3 to see Due Date");
         System.out.println("Enter 4 to exite ");
            System.out.println("Please enter your choice ");
          int accountChoice = input.nextInt(); 
        
           switch (accountChoice){
               case 1:
                  System.out.println("borrowed Book"+account.getBorrowedBook());
                           break ;
               case 2 :  
                   System.out.println("Purchase Date"+account.getPurchaseDate());
                   break ;
               case 3 :
                   System.out.println("Due Date"+account.getDueDate());
                   break ;
               case 4 :
                   System.out.println("End to the account information .");
                   break ;
               default :
                   System.out.println("Please enter number between 1 - 5");
           }
    
            
        MyLibrarySystem library = new MyLibrarySystem(); 
        
        //  BOOKS00(String title, String author, String genre, String language, String publicationDate, String description, double price, boolean isAvailable) 
        library.addBook("Java Basics", "James Gosling", "Educational books", "English", "2021", "Learn Java basics", 86.5 , true);
        library.addBook("Python Advanced", "Guido van Rossum", "Educational books", "English", "2020", "Advanced Python techniques", 70.0 ,false );
        library.addBook("C++ Primer", "Bjarne Stroustrup", "Educational books", "English", "2019", "Comprehensive guide to C++",69.25, false);
        library.addBook("خوارزميات البرمجة", "محمد عبد الله", "Educational books", "Arabic", "2018", "Learn algorithms in an easy way",34.5, true);
        library.addBook("Professional Python", "John Wiley", "Educational books", "English", "2015", "Learn Python to become a professional",119.25, true);
        library.displayBooks();
       
            System.out.println("Library Menu:");
            System.out.println("1. Display Books");
            System.out.println("2. Add a Book");
            System.out.println("3. Remove a Book");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            
        int choice = in.nextInt(); 
        in.nextLine();   
        
            switch (choice) {
                case 1 : library.displayBooks();
                case 2 : {
                    in.nextLine(); // Clear buffer
                    System.out.print("Enter title: ");
                    String title = in.nextLine();
                    
                    System.out.print("Enter author: ");
                    String author = in.nextLine();
                    
                    System.out.print("Enter genre: ");
                    String genre = in.nextLine();
                    
                    System.out.print("Enter language: ");
                    String language = in.nextLine();
                    System.out.print("Enter publication date: ");
                    String publicationDate = in.nextLine();
                    System.out.print("Enter description: ");
                    String description = in.nextLine();
                    System.out.print("Is available (true/false): ");
                    boolean isAvailable = in.nextBoolean();
                    System.out.print("Enter price: ");
                    double price = in.nextDouble();
                    library.addBook(title, author, genre, language, publicationDate, description,price, isAvailable);
                }
                case 3 : {
                    in.nextLine(); // Clear buffer
                    System.out.print("Enter title of the book to remove: ");
                    String title = in.nextLine();
                    library.removeBook(title);
                }
                case 4 : {
                    System.out.println("Exiting the library system.");
                }
                default : System.out.println("Invalid choice. Please try again.");
            }
            
            
            
            
            
            }


}
    
    
    
   





        
    


 
  
 